import json
import boto3
import pymysql
from lambda_cache import secrets_manager
from lambda_cache import ssm
from lambda_cache import s3

secret_name = "yoh-db-rds-dev"

@secrets_manager.cache(name=secret_name, max_age_in_seconds=300)
def getDb(event, context):
    try:
        response = getattr(context, secret_name)
        secretDict = json.loads(response)
    except:
        client = boto3.client('secretsmanager')
        var = secrets_manager.get_entry(name=secret_name, max_age_in_seconds=0)
        response = client.get_secret_value(SecretId = secret_name)
        secretDict = json.loads(response['SecretString'])
        
    return secretDict
    
##@s3.cache(s3Uri='s3://asset.yoyoyoh.com/version.yaml', max_age_in_seconds=300)
##def s3_download_entry_name(event, context):
##    
##    # Object from S3 automatically saved to /tmp directory
##    with open("/tmp/version.yaml") as file_data:
##        status = json.loads(file_data.read())['versions']
##   
##    return status
