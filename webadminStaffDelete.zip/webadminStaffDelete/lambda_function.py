import boto3
import json
from datetime import date
from yoh_cache import *

def lambda_handler(event, context):
    try:
        d = json.loads(event['body'])
        profile_uid = d['profile_uid']
        active = 'D'

    except:
        return {
            'statusCode':400,
            'body': json.dumps("Someting Missing in Reques")
        }

    if profile_uid:
        secretDict = getDb(event, context)
        connection = pymysql.connect(secretDict['host'], secretDict['username'], secretDict['password'], secretDict['dbName'])
        mycursor = connection.cursor()

        sql = ("UPDATE staff SET active = %s, modified_date = %s")
        value = (active, modified_date)
        returnedUpdateRow = mycursor.execute(sql,value)
        connection.commit()

        return {
            'statusCode':200,
            'body':json.dumps("Delete Done !")
        }


    else:
        return {
            'statusCode':404,
            'body': json.dumps("Choose Staff profileto Delete")
        }
